# Diário do Sono — 1.0.2

Aplicação PWA estática em português do Brasil. Sem conta, login, backend de dados ou dependências online. Todos os arquivos necessários estão em **dist/**.

## Publicar

Envie o conteúdo de dist/ a uma hospedagem HTTPS ou à raiz de um repositório com GitHub Pages. Mantenha todas as pastas. Abra o endereço publicado, não um arquivo file://.

## Executar localmente

`python3 -m http.server 8000 --directory dist`

Abra http://localhost:8000. Para testar em aparelho real, use hospedagem HTTPS.

## Guia

Abra dist/Guia_Diario_do_Sono.html para instruções de instalação, preenchimento, contatos, backup, CSV, PDF e envio.

## Dados e formato

IndexedDB: banco diario-do-sono, versão 1; object stores meta e records. Migrações devem ser adicionadas ao onupgradeneeded, sem apagar stores existentes. Meta inclui perfil, configurações e aceite local. Cada registro inclui UUID, data do despertar, status draft/complete, created/updated, respostas e marcações de preenchimento. null representa ausência; zero é um valor real.

JSON oficial: app diario-do-sono; format 1; appVersion; exportedAt; profile; settings portáveis; records (incluindo rascunhos). O aceite e a data de backup local não são transferidos. Não edite manualmente o JSON. CSV não é restaurável; as colunas JSON de cochilos e medicamentos preservam detalhes.

## PDF

Motor PDF local em pdf.js, sem serviço externo. Fontes DejaVu Sans subsetadas e incorporadas em font-data.js; licença em dist/FONT_LICENSE.txt. Relatórios A4 com margens, paginação, gráficos vetoriais em preto e branco e blocos dos 12 itens.

## Atualizações

Altere VERSION em core.js e o nome de CACHE em sw.js; atualize a lista ASSETS quando necessário. Todos os arquivos essenciais são pré-cacheados. O novo worker só assume após confirmação do usuário. Nunca remova IndexedDB durante a atualização. Novos termos relevantes devem alterar TERMS_VERSION. Para mudança de formato de backup, atualize FORMAT e implemente compatibilidade explicitamente.

## Verificação

`node tests.mjs` executa testes de cálculos, validação, CSV e JSON e cria PDFs de teste com dados fictícios. Não contém registros pessoais. Veja VERIFICACAO.md para limites de verificação.

## Compartilhamento

Web Share depende de aparelho/navegador/apps. wa.me e mailto não anexam arquivos; o app fornece download e instruções para anexo manual. Abrir ou compartilhar não prova entrega/leitura.

## Alterações 1.0.1

Guia de uso sem a seção de publicação; durações apresentadas em hh:mm; abas Ajustes e Ajuda independentes; aparência no início dos Ajustes, com aplicação/salvamento imediato; indicador mostra apenas uso aproximado do app. O formato JSON e os minutos armazenados permanecem compatíveis com a versão anterior.

## Alterações 1.0.2

Botão Fechar guia (retorno à Ajuda quando o navegador impede fechar a aba); descrições das duas escalas em Seu despertar; transições do formulário rolam ao topo e posicionam o foco no título.
