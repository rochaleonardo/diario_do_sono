# Verificação da versão 1.0.2

Aprovados por testes automatizados:

- Noite atravessando meia-noite e sono diurno com datas explícitas.
- Sono estimado, tempo na cama, tempo após despertar, cochilos e eficiência.
- Ausência versus zero; valores negativos, fracionários em contagens e escalas fora de 1–5.
- Cronologia e durações incompatíveis.
- JSON: identificação de origem, versão, perfil/contatos, campos inválidos e duplicidade.
- CSV: BOM UTF-8, múltiplos medicamentos, acentos, aspas, quebra de linha e proteção contra fórmula.
- Sintaxe de módulos JavaScript e referências de recursos locais.

PDFs gerados com dados fictícios: um registro e trinta registros com observações extensas. Verificados com Poppler: A4, fontes incorporadas, texto/acento/valores extraídos e páginas renderizadas de identificação, detalhes e continuação. O relatório de um registro pode ocupar várias páginas porque contém resumo, cinco gráficos e os 12 itens; não há redução de fonte para forçar uma página.

Verificação por inspeção de código: aceite bloqueante, transações de importação, manutenção do aceite, ausência de envio do diário a servidores, confirmação de exclusão, manutenção do formulário após falha, atualização preservando IndexedDB e links codificados.

Não foi possível executar testes de interação em navegador neste ambiente. Portanto criação/edição/exclusão e reabertura via interface, IndexedDB real, layout responsivo, cache offline, instalação, atualização e compartilhamento nativo precisam de conferência em navegador/aparelhos reais. Não foram realizados envios reais por WhatsApp/e-mail.

Roteiro recomendado após publicação: aceitar termos → criar perfil → salvar/retomar rascunho → concluir com cochilos/medicamentos → recarregar → editar → exportar JSON/CSV/PDF → restaurar em navegador separado → criar conflito e mesclar → desligar rede e reabrir → verificar compartilhamento e cancelamento em Android/iOS → conferir em computador.

Atualização 1.0.2: nove grupos de testes de cálculos, formatação hh:mm, CSV e backups aprovados. ui-tests.mjs verifica o código da interface com DOM e IndexedDB simulados: seletor antes do perfil, alternância claro/escuro imediata, salvamento do tema, tema do sistema, navegação Ajustes/Ajuda e indicador sem capacidade total. Essa simulação não substitui navegador real. PDFs foram renderizados novamente com hh:mm e quebra por largura real da fonte.

Atualização 1.0.2: botão de fechar guia, fallback de retorno à Ajuda, rótulos completos das avaliações e rolagem/foco ao trocar etapas conferidos no código. Nove grupos de testes e a simulação existente de interface seguem aprovados. Não houve teste em aparelho real nesta atualização.
